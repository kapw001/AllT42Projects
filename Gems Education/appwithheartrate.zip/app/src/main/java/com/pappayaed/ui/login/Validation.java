package com.pappayaed.ui.login;

/**
 * Created by yasar on 22/3/18.
 */

public class Validation {


    private LoginActivity loginActivity;


    public Validation(LoginActivity loginActivity) {
        this.loginActivity = loginActivity;

        init();
    }

    private void init() {


    }
}
