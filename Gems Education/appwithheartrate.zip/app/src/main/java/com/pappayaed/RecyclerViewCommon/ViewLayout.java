package com.pappayaed.RecyclerViewCommon;

/**
 * Created by yasar on 11/4/18.
 */

public interface ViewLayout {

    int getLayoutRes();
}
