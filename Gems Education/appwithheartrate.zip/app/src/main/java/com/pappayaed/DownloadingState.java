package com.pappayaed;

import java.io.Serializable;

/**
 * Created by yasar on 28/4/18.
 */

public enum DownloadingState implements Serializable{
    DOWNLOADING, FINISHED, FAILED;
}
