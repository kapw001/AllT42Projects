package com.pappayaed.ui.studentfee;

import com.pappayaed.base.BasePresenter;
import com.pappayaed.ui.showprofile.StudentList;

import java.util.List;

/**
 * Created by yasar on 26/3/18.
 */

public class StudentFeePresenterImp<V extends IStudentFeeView> extends BasePresenter<V> implements IStudentFeePresenter<V>, IStudentIntractor.OnFinishedListener {

    private IStudentIntractor iStudentIntractor;

    public StudentFeePresenterImp(IStudentIntractor iStudentIntractor) {
        super(iStudentIntractor.getDataSource());
        this.iStudentIntractor = iStudentIntractor;
    }

    @Override
    public void getStudentProfile() {

        getMvpView().showLoading();
        iStudentIntractor.getStudentProfile(this);
    }

    @Override
    public void onSuccss(List<StudentList> studentLists) {

        getMvpView().hideLoading();
        if (studentLists.size() > 0) getMvpView().setData(studentLists);
        else getMvpView().emptyData();


    }

    @Override
    public void onFail(Throwable throwable) {
        getMvpView().hideLoading();
        getMvpView().onFail(throwable);
    }

    @Override
    public void onNetworkFailure() {
        getMvpView().hideLoading();
        getMvpView().onNetworkFailure();
    }
}
