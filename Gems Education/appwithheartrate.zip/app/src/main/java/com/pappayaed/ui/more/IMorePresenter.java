package com.pappayaed.ui.more;

/**
 * Created by yasar on 26/3/18.
 */

public interface IMorePresenter {

    void displayProfile();

    void gotoProfileActivity();

    void logout();
}
