package com.pappayaed.ui.showfeedetails.paymenthistory;

import com.pappayaed.data.model.ResultResponse;

/**
 * Created by yasar on 27/3/18.
 */

public interface IPaymentHistoryPresenter {


    void showTermFees(ResultResponse resultResponse);

}
