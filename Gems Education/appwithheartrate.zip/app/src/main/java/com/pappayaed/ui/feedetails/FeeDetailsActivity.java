package com.pappayaed.ui.feedetails;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.pappayaed.R;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.interfaces.CallBackStudentID;
import com.pappayaed.ui.showprofile.StudentList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FeeDetailsActivity extends BaseActivity implements CallBackStudentID {

    @BindView(R.id.containerfeedetails)
    FrameLayout containerfeedetails;

    private StandardAndFeeFragment standardAndFeeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fee_details2);
        ButterKnife.bind(this);




        if (getSupportActionBar() != null) {
            setCustomView("Fee Details");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

        standardAndFeeFragment = new StandardAndFeeFragment();

        fragmentTransaction.replace(R.id.containerfeedetails, standardAndFeeFragment);

        fragmentTransaction.commit();
    }

    @Override
    public void loadStudentID(StudentList studentList) {

//        Toast.makeText(this, "" + studentList.getId(), Toast.LENGTH_SHORT).show();

        loadStandardAndFeeFragment(studentList);

    }


    private void loadStandardAndFeeFragment(StudentList studentList) {


        standardAndFeeFragment.loadStudentFee(studentList);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                super.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
