package com.pappayaed.ui.splash;

import com.pappayaed.base.BaseView;

/**
 * Created by yasar on 26/3/18.
 */

public interface ISplashView extends BaseView {

    void gotoMainActivity();

    void gotoLoginActivity();

}
