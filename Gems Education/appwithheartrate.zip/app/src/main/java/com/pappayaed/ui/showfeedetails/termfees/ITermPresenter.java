package com.pappayaed.ui.showfeedetails.termfees;

import com.pappayaed.data.model.ResultResponse;

/**
 * Created by yasar on 27/3/18.
 */

public interface ITermPresenter {


    void showTermFees(ResultResponse resultResponse);

}
