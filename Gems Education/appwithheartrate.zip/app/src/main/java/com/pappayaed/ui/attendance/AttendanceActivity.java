package com.pappayaed.ui.attendance;

import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.pappayaed.R;
import com.pappayaed.adapter.AttadanceAdapter;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.interfaces.CallBackStudentID;
import com.pappayaed.common.Utils;
import com.pappayaed.data.model.AttendanceList;
import com.pappayaed.errormsg.Error;
import com.pappayaed.ui.calendarandlistview.CalendarAndListFragment;
import com.pappayaed.ui.showprofile.StudentList;

import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import calendar.android.com.customcalendar.CalendarCustomViewRecycler;
import calendar.android.com.customcalendar.EventHighlight;
import calendar.android.com.customcalendar.EventObjects;
import calendar.android.com.customcalendar.onItemClick;

public class AttendanceActivity extends BaseActivity implements CallBackStudentID, IAttendanceView ,CalendarAndListFragment.OnItemClickCallback{

    private static final String TAG = "AttendanceActivity";

    private IAttendancePresenter iAttendancePresenter;

    private CalendarAndListFragment calendarAndListFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        ButterKnife.bind(this);

        if (getSupportActionBar() != null) {

            getSupportActionBar().setTitle("Attendance");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        }

        calendarAndListFragment = (CalendarAndListFragment) getSupportFragmentManager().findFragmentById(R.id.calendarAndListFragment);

        calendarAndListFragment.setEventHighlight(EventHighlight.RECTANGLE);


        iAttendancePresenter = new AttendancePresenterImpl(this, new AttendanceIntractorImpl(dataSource));


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                super.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void loadStudentID(StudentList studentList) {

//        Toast.makeText(this, "" + studentList.getId(), Toast.LENGTH_SHORT).show();

        iAttendancePresenter.getAttendanceList(studentList, "", "");

    }

    @Override
    public void onFail(Throwable throwable) {

        setEmptyData();
    }

    @Override
    public void onNetworkFailure() {
        setEmptyData();
    }

    @Override
    public void showLoading() {

        Utils.showProgress(this, "Loading");

    }

    @Override
    public void hideLoading() {
        Utils.hideProgress();

    }

    @Override
    public void showSnackBar(View view, String msg) {

    }

    @Override
    public void showToast(String msg) {

    }

    @Override
    public void setData(List<AttendanceList> list) {

        calendarAndListFragment.updateAttendance(list);

    }

    @Override
    public void setEmptyData() {

        calendarAndListFragment.showErrorOrEmptyView(null, false);

    }

    @Override
    public void setEventList(List<EventObjects> eventList) {
        Log.e(TAG, "setEventList: " + eventList.size());

        calendarAndListFragment.updateEventList(eventList);
    }

    @Override
    public void onItemClick(View view, int position, Object o) {


        iAttendancePresenter.onItemClick(view, position, o);


    }
}
