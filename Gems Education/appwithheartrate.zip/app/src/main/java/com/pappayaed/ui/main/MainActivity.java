package com.pappayaed.ui.main;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.pappayaed.R;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.common.BottomNavigationViewHelper;
import com.pappayaed.fragmentnavigation.FragmentNavigationManager;
import com.pappayaed.fragmentnavigation.NavigationManager;
import com.pappayaed.ui.attendance.AttendanceActivity;
import com.pappayaed.ui.circular.CircularActivity;
import com.pappayaed.ui.feedetails.FeeDetailsActivity;
import com.pappayaed.ui.heartrate.HeartRateActivity;
import com.pappayaed.ui.login.LoginActivity;

public class MainActivity extends BaseActivity implements IMainView {

    private Fragment fragment = null;
    private static final String TAG = "MainActivity";

    private NavigationManager navigationManager;
    private IMainPresenter iMainPresenter;
    private BottomNavigationView navigation;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(android.view.Window.FEATURE_CONTENT_TRANSITIONS);
        setContentView(R.layout.activity_main);

        setCustomView(getResources().getString(R.string.title_dashboard));

        navigationManager = FragmentNavigationManager.obtain(this);

        navigation = (BottomNavigationView) findViewById(R.id.navigation);

        BottomNavigationViewHelper.removeShiftMode(navigation);

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        iMainPresenter = new MainPresenterImpl(dataSource);

        iMainPresenter.onAttach(this);
        iMainPresenter.loadMoreFragment();

//        iMainPresenter.bottomNavigationViewPosition(navigation.getMenu().findItem(R.id.txtDate));
        navigation.getMenu().findItem(R.id.circular).setCheckable(false);


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        fragment = navigationManager.getFragment();

    }


    @Override
    public void inflateBottomViewParent() {

//        navigation.getMenu().clear();
//        navigation.inflateMenu(R.menu.buttomtab);

    }


    @Override
    public void moveToEventsActivity() {

//        navigationManager.Circular(getString(R.string.title_circular));
//        setTitle(getString(R.string.title_circular));


        startActivity(new Intent(this, CircularActivity.class));

    }

    @Override
    public void moveToAttendanceActivity() {

//        navigationManager.StudentFeeFragment(getString(R.string.title_fee));
//        setTitle(getString(R.string.title_childern));

        startActivity(new Intent(this, AttendanceActivity.class));
    }

    @Override
    public void moveToMoreFragment() {

        navigationManager.MoreFragment(getString(R.string.title_more));
        setTitle(getString(R.string.title_dashboard));


    }

    @Override
    public void moveToFeeDetailsActivity() {

        startActivity(new Intent(this, FeeDetailsActivity.class));
    }

    @Override
    public void moveToHeartRateActivity() {
        startActivity(new Intent(this, HeartRateActivity.class));
    }

    @Override
    public void logout() {
        startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        iMainPresenter.onDetach();
    }

    private void setTitle(String title) {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);//Menu Resource, Menu
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:

                iMainPresenter.logout();

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            item.setCheckable(false);
            iMainPresenter.bottomNavigationViewPosition(item);

            return true;
        }

    };
}
