package com.pappayaed.dowloadservices;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.pappayaed.common.ActivityUtils;
import com.pappayaed.common.FileSaveAndOpen;
import com.pappayaed.data.DataRepository;
import com.pappayaed.data.DataSource;
import com.pappayaed.data.listener.DataListener;
import com.pappayaed.data.model.AttachmentDetail;
import com.pappayaed.data.model.ResultResponse;
import com.pappayaed.data.pref.Pref;
import com.pappayaed.data.pref.PreferencesHelper;
import com.pappayaed.data.remote.ApiService;
import com.pappayaed.data.remote.RemoteDataSourceHelper;
import com.pappayaed.data.retrofitclient.ApiEndPoint;
import com.pappayaed.data.retrofitclient.RetrofitClient;

import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;


public class DownloadService extends Service implements DownloadServiceCallback {

    private static final String TAG = "DownloadService";
    private String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";
    private Pref pref;
    private RetrofitClient retrofitClient;
    private ApiService apiService;
    private RemoteDataSourceHelper remoteDataSource;
    public DataSource dataSource;

    private Context mContext;

    private IDownloadPresenter iDownloadPresenter;

//    public DownloadService() {
//        super("DownloadService");
//
//
//    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();
        pref = PreferencesHelper.getPreferencesInstance(getApplicationContext());

        retrofitClient = RetrofitClient.getRetrofitClientInstance(ApiEndPoint.BASE_URL);

        apiService = retrofitClient.getRetrofit().create(ApiService.class);

        remoteDataSource = new RemoteDataSourceHelper(apiService);

        dataSource = new DataRepository(getApplicationContext(), remoteDataSource, pref);

        iDownloadPresenter = new DownloadServiceImpl(this, pref, retrofitClient, apiService, remoteDataSource, dataSource);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        mContext = getApplicationContext();

        onHandleIntent(intent);

        return START_STICKY;
    }


    protected void onHandleIntent(final Intent intent) {

        if (intent != null) {

//            synchronized (intent) {
//
//            NotificationChannel notificationChannel = null;
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_MAX);
//
//                // Configure the notification channel.
//                notificationChannel.setDescription("Channel description");
//                notificationChannel.enableLights(true);
//                notificationChannel.setLightColor(Color.RED);
//                notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
//                notificationChannel.enableVibration(true);
//            }
////
//            final NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
//                    .setSmallIcon(R.mipmap.ic_launcher)
//                    .setTicker("Your Ticker") // use something from something from R.string
//                    .setContentTitle("Your content title") // use something from something from
//                    .setContentText("Your content text") // use something from something from
//                    ; // display indeterminate progress


//            try {
//                Thread.sleep(5000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }


            new Thread(new Runnable() {
                @Override
                public void run() {


                    final String action = intent.getAction();

                    if (action.equalsIgnoreCase("download")) {

                        String attachId = intent.getStringExtra("attachment_id");

                        if (dataSource.getState(attachId).equalsIgnoreCase("init") || dataSource.getState(attachId).equalsIgnoreCase("failed")) {

                            dataSource.saveDownloadedfile(attachId, "downloading");


                            downLoading(attachId);
//                            NotificationCompat.Builder builder = iDownloadPresenter.getBuilder();
//                            if (builder != null) {
//
//                                startForeground(Integer.parseInt(attachId), builder.build());
//                            }


                        } else {

                            if (dataSource.getState(attachId).equalsIgnoreCase("finished") || dataSource.getState(attachId).equalsIgnoreCase("downloading")) {


                                String fileName = intent.getStringExtra("name");

                                Log.e(TAG, "onHandleIntent: ddddddd   " + attachId + "   :    " + fileName);

                                if (FileSaveAndOpen.isFileExists(fileName)) {
                                    showDownloadFile(FileSaveAndOpen.getFile(fileName));
                                } else {

                                    dataSource.saveDownloadedfile(attachId, "downloading");


                                    downLoading(attachId);
//                                    NotificationCompat.Builder builder = iDownloadPresenter.getBuilder();
//                                    if (builder != null) {
//                                        startForeground(Integer.parseInt(attachId), builder.build());
//                                    }
//                            startForeground(Integer.parseInt(attachId), builder.build());

                                    Log.e(TAG, "onHandleIntent: " + "There is no file, something went wrong so that re downloading   ");

//                                Toast.makeText(this, "There is no file, something went wrong", Toast.LENGTH_SHORT).show();

                                }

                            }

                        }


                    } else if (action.equalsIgnoreCase("finished")) {
                        int attachId = intent.getIntExtra("attachment_id", 0);

                        String fileName = intent.getStringExtra("name");

                        if (FileSaveAndOpen.isFileExists(fileName)) {
                            showDownloadFile(FileSaveAndOpen.getFile(fileName));
                        } else {

                            Log.e(TAG, "onHandleIntent: There is no file, something went wrong ");
//                        Toast.makeText(this, "There is no file, something went wrong", Toast.LENGTH_SHORT).show();

                        }

                    }


                }
            }).start();


        }
//        }

    }


    public void showDownloadFile(File myFile) {


        FileSaveAndOpen.openFile(this, myFile);

    }


    private void downLoading(final String attachId) {

        iDownloadPresenter.download(this, attachId);


    }


    @Override
    public void downloadFile(AttachmentDetail attachmentDetail) {
        stopSelf();
        iDownloadPresenter.downloadFile(this, attachmentDetail);


    }

    @Override
    public void failed(String attachId) {
        stopSelf();
        iDownloadPresenter.failed(this, attachId);


    }

    @Override
    public void progressUpadte(int id, int max, int progress, boolean indeterminate) {

    }


    @Override
    public void onDestroy() {
        Log.e(TAG, "onDestroy: Intent services ");
        super.onDestroy();


    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    static class DownloadFile extends AsyncTask<Integer, Integer, AttachmentDetail> {

        private IDownloadPresenter iDownloadPresenter;
        private ProgressNotification notification;
        private DataSource dataSource;
        private AttachmentDetail attachmentDetail = null;
        private Context context;
        private int id;

        DownloadFile(IDownloadPresenter iDownloadPresenter, DataSource dataSource, Context context, int id) {
            this.iDownloadPresenter = iDownloadPresenter;
            this.dataSource = dataSource;
            this.context = context;
            this.notification = new ProgressNotification(context);
            this.id = id;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            notification.updateProgress(id, 100, 0, false);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            // Update progress
            notification.updateProgress(id, 100, values[0], false);
            super.onProgressUpdate(values);
        }

        @Override
        protected AttachmentDetail doInBackground(Integer... params1) {


            Map<Object, Object> json = new HashMap<>();
            Map<Object, Object> params = new HashMap<>();
            params.put("login", dataSource.getEmailOrUsername());
            params.put("password", dataSource.getPassword());
            params.put("user_type", dataSource.getUserType());
            params.put("attachment_id", id);
            json.put("params", params);

            final String js = new JSONObject(json).toString();

            dataSource.getAttachment_id_data(js, new DataListener() {
                @Override
                public void onSuccess(Object object) {

                    ResultResponse resultResponse = (ResultResponse) object;

                    try {

                        if (resultResponse.getResult().getAttachmentDetail() != null) {

                            attachmentDetail = resultResponse.getResult().getAttachmentDetail();


                        } else {
                            attachmentDetail = null;

                        }
                    } catch (NullPointerException e) {
                        attachmentDetail = null;
                    }

                }

                @Override
                public void onFail(Throwable throwable) {
                    attachmentDetail = null;
                }

                @Override
                public void onNetworkFailure() {
                    attachmentDetail = null;
                }
            });


            int i;
            for (i = 0; i <= 100; i += 5) {
                // Sets the progress indicator completion percentage
                publishProgress(Math.min(i, 100));
                try {
                    // Sleep for 5 seconds
                    Thread.sleep(2 * 1000);
                } catch (InterruptedException e) {
                    Log.d("TAG", "sleep failure");
                }
            }


            return attachmentDetail;
        }

        @Override
        protected void onPostExecute(AttachmentDetail attachmentDetail) {
            super.onPostExecute(attachmentDetail);


            if (attachmentDetail != null) {

                Bundle bundle = new Bundle();
                bundle.putInt("attachment_id", attachmentDetail.getAttachId());
                bundle.putString("name", attachmentDetail.getName());
                Intent intent = ActivityUtils.getIntentWithAction(context, DownloadService.class, bundle, "finished");


                PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                notification.setPendingIntent(pendingIntent);
                notification.setContentText("Download complete");
                notification.updateProgress(id, 0, 0, false);

                iDownloadPresenter.downloadFile(context, attachmentDetail);


            } else {

                Bundle bundle = new Bundle();
                Intent intent = ActivityUtils.getIntentWithAction(context, DownloadService.class, bundle, "finished Nothing");


                PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                notification.setPendingIntent(pendingIntent);
                notification.setContentText("Download complete");
                notification.updateProgress(id, 0, 0, false);

                Log.e(TAG, "onPostExecute: download Failed ");

            }


        }
    }


}




