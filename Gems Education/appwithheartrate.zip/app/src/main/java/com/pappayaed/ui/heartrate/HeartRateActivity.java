package com.pappayaed.ui.heartrate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.pappayaed.R;
import com.pappayaed.common.Utils;
import com.pappayaed.interfaces.CallBackStudentID;
import com.pappayaed.ui.showprofile.StudentList;

public class HeartRateActivity extends AppCompatActivity implements CallBackStudentID {


    private HeartRateChartFragment heartRateChartFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate);

        if (getSupportActionBar() != null) {

            getSupportActionBar().setTitle("Heart Rate");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        }

        heartRateChartFragment = (HeartRateChartFragment) getSupportFragmentManager().findFragmentById(R.id.heartRateChartFragment);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                super.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void loadStudentID(StudentList studentList) {


        heartRateChartFragment.loadStudentData(studentList);

    }

    @Override
    public void onFail(Throwable throwable) {

        setEmptyData();
    }

    @Override
    public void onNetworkFailure() {
        setEmptyData();
    }

    @Override
    public void showLoading() {

        Utils.showProgress(this, "Loading");

    }

    @Override
    public void hideLoading() {
        Utils.hideProgress();

    }


    public void setEmptyData() {

        Toast.makeText(this, "There is no data", Toast.LENGTH_SHORT).show();

    }
}
