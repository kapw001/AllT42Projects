package com.pappayaed.data.local;

/**
 * Created by yasar on 22/3/18.
 */

public interface LocalDataSource {
}
