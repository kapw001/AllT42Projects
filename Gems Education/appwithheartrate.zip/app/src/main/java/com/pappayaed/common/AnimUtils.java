package com.pappayaed.common;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.pappayaed.R;

/**
 * Created by yasar on 25/4/18.
 */

public class AnimUtils {

    public static void setAnim(Context context, View view) {

//        Animation animation = AnimationUtils.loadAnimation(context,
//                R.anim.item_animation_fall_down);
//        animation.setStartOffset(100);
//        view.startAnimation(animation);

    }

    public static void setAnimSlideLeft(Context context, View view) {

//        Animation animation = AnimationUtils.loadAnimation(context,
//                R.anim.up_from_bottom);
//        animation.setStartOffset(100);
//        view.startAnimation(animation);
//
//        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "translationY", 100, 0);
//        objectAnimator.setDuration(500);
//        objectAnimator.setStartDelay(100);
//        objectAnimator.start();

    }

    public static void setAnimAlpha(Context context, View view) {

//        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
//        anim.setDuration(1500);
//        anim.setStartOffset(100);
//        view.startAnimation(anim);

    }

    public static void setAnimTranslationY(Context context, View view) {

//        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
//        anim.setDuration(1500);
//        anim.setStartOffset(100);
//        view.startAnimation(anim);

//        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "translationY", 100, 0);
//        objectAnimator.setDuration(500);
//        objectAnimator.setStartDelay(100);
//        objectAnimator.start();


    }
}
