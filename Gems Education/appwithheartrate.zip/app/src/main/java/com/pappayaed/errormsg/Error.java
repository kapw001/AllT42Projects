package com.pappayaed.errormsg;

/**
 * Created by yasar on 10/5/17.
 */

public interface Error {

    String servererror = "Check your internet connection and try again";
    String usererror = "Please enter a valid username";
    String emailerror = "Please enter a valid email";
    String passwoderror = "Please enter a password";
    String odooservererror = "PappayaED server error,please try again later";
    String nodata = "There is no data";
    String no_data_payment_history = "There is no data";
    String noattendancedata = "There is no data";
    String error = "Server could not be connected, please try again later";
}
