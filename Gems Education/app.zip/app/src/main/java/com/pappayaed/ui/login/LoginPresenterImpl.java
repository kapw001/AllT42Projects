package com.pappayaed.ui.login;

import android.text.TextUtils;

/**
 * Created by yasar on 17/4/17.
 */

public class LoginPresenterImpl implements ILoginPresenter, ILoginIntractor.OnFinishedListener {


    private ILoginView iLoginView;

    private LoginIntractorImpl iLoginIntractor;


    public LoginPresenterImpl(ILoginView iLoginView, LoginIntractorImpl iLoginIntractor) {

        this.iLoginView = iLoginView;
        this.iLoginIntractor = iLoginIntractor;
    }

    @Override
    public void validateCredentials(String username, String password) {

        if (TextUtils.isEmpty(username)) {
            iLoginView.showEmailError();
            return;
        } else if (TextUtils.isEmpty(password)) {
            iLoginView.showPasswordError();
            return;
        }

        iLoginView.showLoading();
        iLoginIntractor.validateCredentials(username, password, this);
//        getList();

    }

    @Override
    public void getList() {

        iLoginIntractor.getList(this);

    }


    @Override
    public void onSuccssLogin(String s) {

        iLoginView.hideLoading();
//        iLoginView.onSuccssLogin(s);
        iLoginView.gotoMainActivity();
    }


    @Override
    public void onFail(Throwable throwable) {

        iLoginView.hideLoading();


        if (throwable.getMessage().equalsIgnoreCase("Invalid Email ID and Password")) {
            iLoginView.showEmailAndPasswordError();
            return;
        }

        iLoginView.onFail(throwable);

    }

    @Override
    public void onNetworkFailure() {

        iLoginView.hideLoading();
        iLoginView.onNetworkFailure();
    }

}
