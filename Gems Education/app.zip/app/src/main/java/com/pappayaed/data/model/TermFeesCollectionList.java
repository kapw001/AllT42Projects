package com.pappayaed.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by yasar on 19/12/17.
 */

public class TermFeesCollectionList implements Serializable, Parcelable
{

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("parent_name")
    @Expose
    private String parentName;
    @SerializedName("amount")
    @Expose
    private Double amount;
    @SerializedName("grade_name")
    @Expose
    private String gradeName;
    @SerializedName("term_name")
    @Expose
    private String termName;
    @SerializedName("due_date")
    @Expose
    private String dueDate;
    @SerializedName("student_id")
    @Expose
    private Long studentId;
//    @SerializedName("term_id")
//    @Expose
//    private Long termId;
    @SerializedName("student_name")
    @Expose
    private String studentName;
    @SerializedName("grade_id")
    @Expose
    private Long gradeId;
    public final static Parcelable.Creator<TermFeesCollectionList> CREATOR = new Creator<TermFeesCollectionList>() {


        @SuppressWarnings({
                "unchecked"
        })
        public TermFeesCollectionList createFromParcel(Parcel in) {
            return new TermFeesCollectionList(in);
        }

        public TermFeesCollectionList[] newArray(int size) {
            return (new TermFeesCollectionList[size]);
        }

    }
            ;
    private final static long serialVersionUID = 2916022833725525335L;

    protected TermFeesCollectionList(Parcel in) {
        this.status = ((String) in.readValue((String.class.getClassLoader())));
        this.parentName = ((String) in.readValue((String.class.getClassLoader())));
        this.amount = ((Double) in.readValue((Double.class.getClassLoader())));
        this.gradeName = ((String) in.readValue((String.class.getClassLoader())));
        this.termName = ((String) in.readValue((String.class.getClassLoader())));
        this.dueDate = ((String) in.readValue((String.class.getClassLoader())));
        this.studentId = ((Long) in.readValue((Long.class.getClassLoader())));
//        this.termId = ((Long) in.readValue((Long.class.getClassLoader())));
        this.studentName = ((String) in.readValue((String.class.getClassLoader())));
        this.gradeId = ((Long) in.readValue((Long.class.getClassLoader())));
    }

    public TermFeesCollectionList() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public String getTermName() {
        return termName;
    }

    public void setTermName(String termName) {
        this.termName = termName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

//    public Long getTermId() {
//        return termId;
//    }
//
//    public void setTermId(Long termId) {
//        this.termId = termId;
//    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Long getGradeId() {
        return gradeId;
    }

    public void setGradeId(Long gradeId) {
        this.gradeId = gradeId;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(status);
        dest.writeValue(parentName);
        dest.writeValue(amount);
        dest.writeValue(gradeName);
        dest.writeValue(termName);
        dest.writeValue(dueDate);
        dest.writeValue(studentId);
//        dest.writeValue(termId);
        dest.writeValue(studentName);
        dest.writeValue(gradeId);
    }

    public int describeContents() {
        return 0;
    }

}