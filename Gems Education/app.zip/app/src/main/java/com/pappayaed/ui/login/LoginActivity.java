package com.pappayaed.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;

import com.pappayaed.ui.main.MainActivity;
import com.pappayaed.R;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.common.Utils;
import com.pappayaed.data.helper.LogHelper;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends BaseActivity implements ILoginView {

    private static final String TAG = "LoginActivity";

    @BindView(R.id.username)
    AppCompatEditText username;
    @BindView(R.id.password)
    AppCompatEditText password;
    @BindView(R.id.login)
    Button login;

    private ILoginPresenter loginPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);


        LoginIntractorImpl iLoginIntractor = new LoginIntractorImpl(dataSource);

        loginPresenter = new LoginPresenterImpl(this, iLoginIntractor);


    }


    @OnClick(R.id.login)
    public void loginClick(View view) {

        String userName = username.getText().toString();
        String passWord = password.getText().toString();

        loginPresenter.validateCredentials(userName, passWord);

    }

    @Override
    public void onFail(Throwable throwable) {

        LogHelper.loge(throwable.getMessage());

        showSnackBar(findViewById(R.id.loginroot), throwable.getMessage());
    }

    @Override
    public void onNetworkFailure() {
        LogHelper.loge("There is no network");
    }

    @Override
    public void showEmailError() {

        LogHelper.loge("Invalid Email ID");

        showSnackBar(findViewById(R.id.loginroot), "Invalid Email ID");

    }

    @Override
    public void showPasswordError() {
        LogHelper.loge("Invalid Password");

        showSnackBar(findViewById(R.id.loginroot), "Invalid Password");
    }

    @Override
    public void showEmailAndPasswordError() {

        LogHelper.loge("Invalid Email ID and Password");
        showSnackBar(findViewById(R.id.loginroot), "Invalid Email ID and Password");
    }

    @Override
    public void onSuccssLogin(String s) {
        LogHelper.loge(s);
    }

    @Override
    public void gotoMainActivity() {

        startActivity(new Intent(this, MainActivity.class));
        finish();

    }


    @Override
    public void showLoading() {

        Utils.showProgress(this, "Loading...");

        LogHelper.loge("Loading...");
    }

    @Override
    public void hideLoading() {

        Utils.hideProgress();

        LogHelper.loge("Called");
    }


}
