package com.pappayaed.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.pappayaed.App.App;
import com.pappayaed.ui.homework.HomeWorkActivity;
import com.pappayaed.ui.attendance.FeeAttendanceActivity;
import com.pappayaed.ui.showfeedetails.FeeDetailsActivity;
import com.pappayaed.R;
import com.pappayaed.ui.showprofile.StudentList;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class StudentFeeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<StudentList> list;
    private static RecyclerAdapterPositionClicked recyclerAdapterPositionClicked;
    private static Context context;
    private final ViewBinderHelper viewBinderHelper = new ViewBinderHelper();
    private static final int UNSELECTED = -1;
    private static RecyclerView recyclerView;
    private static int selectedItem = UNSELECTED;

    public StudentFeeAdapter() {
        // uncomment the line below if you want to open only one row at a time
        // viewBinderHelper.setOpenOnlyOne(true);
    }

    public StudentFeeAdapter(Fragment context, List<StudentList> list, RecyclerView recyclerView) {
        this.list = list;

        this.context = context.getContext();
        this.recyclerAdapterPositionClicked = (RecyclerAdapterPositionClicked) context;
        this.recyclerView = recyclerView;
        viewBinderHelper.setOpenOnlyOne(true);

    }

    public StudentFeeAdapter(Context context, List<StudentList> list, RecyclerView recyclerView) {
        this.list = list;
        this.context = context;
        this.recyclerAdapterPositionClicked = (RecyclerAdapterPositionClicked) context;
        this.recyclerView = recyclerView;
        viewBinderHelper.setOpenOnlyOne(true);
    }

    public void updateList(List<StudentList> list) {
        this.list = new ArrayList<>();
        this.list.addAll(list);
        notifyDataSetChanged();

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_row, parent, false);
        return new RowViewHolder(view);

    }

    public void saveStates(Bundle outState) {
        viewBinderHelper.saveStates(outState);
    }

    public void restoreStates(Bundle inState) {
        viewBinderHelper.restoreStates(inState);
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final StudentList object = list.get(position);

        Log.e("Id   ", "onBindViewHolder: " + object.getId());

        ((RowViewHolder) holder).name.setText(object.getName().toString());
        ((RowViewHolder) holder).title.setText("Child Name");
        ((RowViewHolder) holder).itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                CharSequence items[] = new CharSequence[]{"Attendance", "Fee Details"};

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.dialog_animation));
                builder.setTitle("Choose");
                builder.setCancelable(true);

                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.e("value is", "" + which);
                        switch (which) {
//                            case 0:
//                                context.startActivity(new Intent(context, HomeWorkActivity.class).putExtra("studentid", object.getId()));
//                                break;
                            case 0:
                                context.startActivity(new Intent(context, FeeAttendanceActivity.class).putExtra("studentid", object.getId()));


                                break;
                            case 1:
                                context.startActivity(new Intent(context, FeeDetailsActivity.class).putExtra("studentid", object.getId()));
                                break;
                            case 2:
                                dialog.dismiss();
                                break;
                        }
                    }
                });

                dialog = builder.create();
//                builder.show();
                dialog.getWindow().getAttributes().windowAnimations =
                        R.style.dialog_animation;

                dialog.show();


//                Toast.makeText(context, "" + isFee, Toast.LENGTH_SHORT).show();


//                if (isFee == StudentStatus.HOMEWORK) {
//                    context.startActivity(new Intent(context, HomeWorkActivity.class).putExtra("studentid", object.getId()));
//                } else if (isFee == StudentStatus.FEES) {
//                    context.startActivity(new Intent(context, FeeDetailsActivity.class).putExtra("studentid", object.getId()));
//                } else {
//                    context.startActivity(new Intent(context, FeeAttendanceActivity.class).putExtra("studentid", object.getId()));
//                }


            }
        });
//        ((RowViewHolder) holder).profileImage.setImageResource(R.draw);


    }


    @Override
    public int getItemCount() {
        if (list == null)
            return 0;
        return list.size();
    }


    private static class RowViewHolder extends RecyclerView.ViewHolder {
        private TextView title, name;
        private CircleImageView profileImage;

        private ImageView arrowImg;

        public RowViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.rowtitle);
            name = (TextView) itemView.findViewById(R.id.profilename);
            profileImage = (CircleImageView) itemView.findViewById(R.id.profile_image);
            arrowImg = (ImageView) itemView.findViewById(R.id.arrow);

        }


    }

    public interface RecyclerAdapterPositionClicked {
        void position(int pos, View view);

        void onRefresh();
    }

    private static void showToat(View view) {
        Toast.makeText(view.getContext(), "" + view.getId(), Toast.LENGTH_SHORT).show();
    }
}
