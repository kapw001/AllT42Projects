package com.pappayaed.ui.splash;

import android.os.Handler;

import com.pappayaed.data.DataSource;

/**
 * Created by yasar on 26/3/18.
 */

public class SplashPresenterImpl implements ISplashPresenter {

    private ISplashView iSplashView;
    private static final int AUTOTIME = 2000;

    private Handler handler;

    private DataSource dataRepository;

    public SplashPresenterImpl(DataSource dataRepository, ISplashView iSplashView) {
        this.iSplashView = iSplashView;
        this.dataRepository = dataRepository;
    }

    @Override
    public void moveToNextActivity() {

        if (handler == null) {
            handler = new Handler();

            handler.postDelayed(runnable, AUTOTIME);
        }

    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {

            if (dataRepository.isLoggedIn()) iSplashView.gotoMainActivity();
            else iSplashView.gotoLoginActivity();

        }
    };


    @Override
    public void cancelHandler() {

        if (handler != null) {

            handler.removeCallbacks(runnable);
            handler = null;
        }

    }
}
