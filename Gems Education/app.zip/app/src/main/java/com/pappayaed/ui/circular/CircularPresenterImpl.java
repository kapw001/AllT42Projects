package com.pappayaed.ui.circular;

import com.pappayaed.data.model.Circular;
import com.pappayaed.data.model.CircularAndHomeWork;

import java.util.List;

/**
 * Created by yasar on 27/3/18.
 */

public class CircularPresenterImpl implements ICircularPresenter, ICircularIntractor.OnFinishedListener {

    private ICircularView iCircularView;
    private ICircularIntractor iCircularIntractor;

    private CircularAndHomeWork circularAndHomeWork;

    public CircularPresenterImpl(ICircularView iCircularView, ICircularIntractor iCircularIntractor) {
        this.iCircularView = iCircularView;
        this.iCircularIntractor = iCircularIntractor;
    }

    @Override
    public void getCircularAndHomeWork() {

        iCircularView.showLoading();
        iCircularIntractor.getCircularAndHomework(this);

    }

//    @Override
//    public void onSuccss(List<Circular> circularList) {
//
//        iCircularView.hideLoading();
//        iCircularView.setData(circularList);
//
//
//    }

    @Override
    public void onSuccss(CircularAndHomeWork circularAndHomeWork) {

        this.circularAndHomeWork = circularAndHomeWork;

        iCircularView.hideLoading();

        loadCircularData();
    }


    public void loadCircularData() {

        if (circularAndHomeWork != null && circularAndHomeWork.getCircularList().size() > 0)
            iCircularView.setDataCircular(circularAndHomeWork.getCircularList());
        else iCircularView.onFail(new Throwable("Something went wrong"));

    }

    public void loadHomeWOrkData() {

        if (circularAndHomeWork != null && circularAndHomeWork.getHomeCircularList().size() > 0)
            iCircularView.setDataHome(circularAndHomeWork.getHomeCircularList());
        else iCircularView.onFail(new Throwable("Something went wrong"));

    }


    @Override
    public void onFail(Throwable throwable) {
        iCircularView.hideLoading();
        iCircularView.onFail(throwable);
    }

    @Override
    public void onNetworkFailure() {

        iCircularView.hideLoading();
        iCircularView.onNetworkFailure();
    }
}
