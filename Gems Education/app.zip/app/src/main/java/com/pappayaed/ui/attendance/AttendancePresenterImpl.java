package com.pappayaed.ui.attendance;

import com.pappayaed.data.model.AttendanceList;
import com.pappayaed.data.model.ResultResponse;

import java.util.List;

/**
 * Created by yasar on 27/3/18.
 */

public class AttendancePresenterImpl implements IAttendancePresenter, IAttendanceIntractor.OnFinishedListener {


    private IAttendanceView iAttendanceView;
    private IAttendanceIntractor iAttendanceIntractor;

    public AttendancePresenterImpl(IAttendanceView iAttendanceView, IAttendanceIntractor iAttendanceIntractor) {
        this.iAttendanceView = iAttendanceView;
        this.iAttendanceIntractor = iAttendanceIntractor;
    }


    @Override
    public void getAttendanceList(long student_ID, String start_date, String end_date) {


        iAttendanceView.showLoading();
        iAttendanceIntractor.getStudentFeeList(student_ID, start_date, end_date, this);

    }

    @Override
    public void onSuccss(ResultResponse response) {


        iAttendanceView.hideLoading();
        if (response.getResult().getAttendanceList() != null && !response.getResult().getAttendanceList().isEmpty()) {
            List<AttendanceList> list = response.getResult().getAttendanceList();
            iAttendanceView.setData(list);
        } else iAttendanceView.setEmptyData();

    }

    @Override
    public void onFail(Throwable throwable) {

        iAttendanceView.hideLoading();
        iAttendanceView.setEmptyData();

    }

    @Override
    public void onNetworkFailure() {

        iAttendanceView.hideLoading();
        iAttendanceView.setEmptyData();

    }
}
