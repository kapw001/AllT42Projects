package com.pappayaed.data.local;

import com.pappayaed.data.DataSource;
import com.pappayaed.data.listener.DataListener;

/**
 * Created by yasar on 9/3/18.
 */

public class LocalDataSourceHelper implements LocalDataSource {


}
