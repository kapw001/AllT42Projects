package com.pappayaed.base;

/**
 * Created by yasar on 26/3/18.
 */

public interface BaseView {


    void onFail(Throwable throwable);

    void onNetworkFailure();

    void showLoading();

    void hideLoading();
}
