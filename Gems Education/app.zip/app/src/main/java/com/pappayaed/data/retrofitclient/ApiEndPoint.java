package com.pappayaed.data.retrofitclient;

/**
 * Created by yasar on 28/2/18.
 */

public final class ApiEndPoint {

//        public static final String BASE_URL = "https://gemspreprod.pappaya.education/";
    public static final String BASE_URL = "https://sitgems2.pappaya.education/";
//    public static final String BASE_URL = "https://testgems.pappaya.education/";
//    public static final String LOGIN = "api/login";

}
