package com.pappayaed.data.model;

/**
 * Created by yasar on 20/3/18.
 */

public class Circular {

    private String description;
    private String txtdate;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTxtdate() {
        return txtdate;
    }

    public void setTxtdate(String txtdate) {
        this.txtdate = txtdate;
    }
}
