package com.pappayaed.ui.circular;

import com.pappayaed.base.BaseView;
import com.pappayaed.data.model.AssignmentSubLine;
import com.pappayaed.data.model.Circular;

import java.util.List;

/**
 * Created by yasar on 27/3/18.
 */

public interface ICircularView extends BaseView {


    void setDataCircular(List<Circular> circularList);

    void setDataHome(List<AssignmentSubLine> homeList);

    void setEmptyData();

}
