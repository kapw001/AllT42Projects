package com.pappayaed.ui.main;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.view.MenuItem;

import com.pappayaed.R;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.fragmentnavigation.FragmentNavigationManager;
import com.pappayaed.fragmentnavigation.NavigationManager;

public class MainActivity extends BaseActivity implements IMainView {

    private Fragment fragment = null;
    private static final String TAG = "MainActivity";

    private NavigationManager navigationManager;
    private IMainPresenter iMainPresenter;
    private BottomNavigationView navigation;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(android.view.Window.FEATURE_CONTENT_TRANSITIONS);
        setContentView(R.layout.activity_main);

        navigationManager = FragmentNavigationManager.obtain(this);

        navigation = (BottomNavigationView) findViewById(R.id.navigation);

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        iMainPresenter = new MainPresenterImpl(this, dataSource);

        iMainPresenter.bottomNavigationViewPosition(navigation.getMenu().findItem(R.id.circular));


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        fragment = navigationManager.getFragment();

    }


    @Override
    public void inflateBottomViewParent() {

        navigation.getMenu().clear();
        navigation.inflateMenu(R.menu.buttomtab);

    }


    @Override
    public void moveToCircularFragment() {

        navigationManager.Circular(getString(R.string.title_circular));
        setTitle(getString(R.string.title_circular));


    }

    @Override
    public void moveToStudentFeeFragment() {

        navigationManager.StudentFeeFragment(getString(R.string.title_fee));
        setTitle(getString(R.string.title_childern));

    }

    @Override
    public void moveToMoreFragment() {

        navigationManager.MoreFragment(getString(R.string.title_more));
        setTitle(getString(R.string.title_more));

    }

    private void setTitle(String title) {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            iMainPresenter.bottomNavigationViewPosition(item);

            return true;
        }

    };
}
