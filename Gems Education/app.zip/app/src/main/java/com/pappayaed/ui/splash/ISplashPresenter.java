package com.pappayaed.ui.splash;

/**
 * Created by yasar on 26/3/18.
 */

public interface ISplashPresenter {


    void moveToNextActivity();

    void cancelHandler();

}
