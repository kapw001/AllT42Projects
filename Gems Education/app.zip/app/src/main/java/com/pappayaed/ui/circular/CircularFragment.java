package com.pappayaed.ui.circular;


import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.pappayaed.R;
import com.pappayaed.adapter.CircularAdapter;
import com.pappayaed.adapter.SubmissionListAdapter;
import com.pappayaed.base.BaseFragment;
import com.pappayaed.common.Utils;
import com.pappayaed.data.model.AssignmentSubLine;
import com.pappayaed.data.model.Circular;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import info.hoang8f.android.segmented.SegmentedGroup;

/**
 * A simple {@link Fragment} subclass.
 */
public class CircularFragment extends BaseFragment implements ICircularView, RadioGroup.OnCheckedChangeListener, SubmissionListAdapter.RecyclerAdapterPositionClicked {


    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    Unbinder unbinder;
    @BindView(R.id.error)
    TextView error;
    @BindView(R.id.circular)
    RadioButton circular;
    @BindView(R.id.homework)
    RadioButton homework;
    @BindView(R.id.segmented2)
    SegmentedGroup segmented2;
    @BindView(R.id.swipeToRefresh)
    SwipeRefreshLayout swipeToRefresh;

    private CircularAdapter circularAdapter;

    private SubmissionListAdapter homeWorkAdapter;

    private ICircularPresenter iCircularPresenter;

    public CircularFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_circular, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        recyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerview.setHasFixedSize(true);

        segmented2.setOnCheckedChangeListener(this);

        iCircularPresenter = new CircularPresenterImpl(this, new CircularIntractorImpl(dataSource));


        swipeToRefresh.setRefreshing(true);
        iCircularPresenter.getCircularAndHomeWork();

        swipeToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                iCircularPresenter.getCircularAndHomeWork();
            }
        });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }


    @Override
    public void onFail(Throwable throwable) {

        swipeToRefresh.setRefreshing(false);
        Log.e("Tag ", "onFail: " + throwable.getMessage());

        setEmptyData();
    }

    @Override
    public void onNetworkFailure() {
        swipeToRefresh.setRefreshing(false);
        setEmptyData();

    }

    @Override
    public void showLoading() {
        swipeToRefresh.setRefreshing(false);
        Utils.showProgress(getActivity(), "Loading");

    }

    @Override
    public void hideLoading() {
        swipeToRefresh.setRefreshing(false);
        Utils.hideProgress();

    }

//    @Override
//    public void setData(List<Circular> circularList) {
//
//        circularAdapter.updateList(circularList);
//        error.setVisibility(View.GONE);
//        recyclerview.setVisibility(View.VISIBLE);
//
//
//    }

    @Override
    public void setDataCircular(List<Circular> circularList) {
        swipeToRefresh.setRefreshing(false);
//        recyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        circularAdapter = new CircularAdapter(this, circularList);
        recyclerview.setAdapter(circularAdapter);
//        recyclerview.addItemDecoration(new DividerItemDecoration(getContext(), R.drawable.divider));
        error.setVisibility(View.GONE);
        recyclerview.setVisibility(View.VISIBLE);

    }

    @Override
    public void setDataHome(List<AssignmentSubLine> homeList) {
        swipeToRefresh.setRefreshing(false);
//        recyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        homeWorkAdapter = new SubmissionListAdapter(this, homeList, recyclerview);
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        recyclerview.setAdapter(homeWorkAdapter);
        error.setVisibility(View.GONE);
        recyclerview.setVisibility(View.VISIBLE);
    }

    @Override
    public void setEmptyData() {
        swipeToRefresh.setRefreshing(false);
        error.setVisibility(View.VISIBLE);
        recyclerview.setVisibility(View.GONE);
//        Toast.makeText(getActivity(), "There", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

        switch (checkedId) {

            case R.id.circular:

                iCircularPresenter.loadCircularData();

                break;

            case R.id.homework:

                iCircularPresenter.loadHomeWOrkData();

                break;

        }

    }

    @Override
    public void position(int pos, View view) {

    }

    @Override
    public void onRefresh() {

    }
}
