package com.pappayaed.ui.circular;

/**
 * Created by yasar on 27/3/18.
 */

public interface ICircularPresenter {


    void getCircularAndHomeWork();

    void loadCircularData();

    void loadHomeWOrkData();


}
