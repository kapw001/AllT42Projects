package com.pappayaed.ui.showfeedetails;

import com.pappayaed.data.model.ResultResponse;

/**
 * Created by yasar on 27/3/18.
 */

public class FeePresenter implements IFeeDetailsPresenter, IFeeIntractor.OnFinishedListener {

    private IFeeIntractor iFeeIntractor;
    private IFeeDetailsView iFeeDetailsView;

    public FeePresenter(IFeeIntractor iFeeIntractor, IFeeDetailsView iFeeDetailsView) {
        this.iFeeIntractor = iFeeIntractor;
        this.iFeeDetailsView = iFeeDetailsView;
    }

    @Override
    public void getStudentFeeList(long id) {

        iFeeDetailsView.showLoading();

        iFeeIntractor.getStudentFeeList(id, this);

    }

    @Override
    public void onSuccss(ResultResponse resultResponse) {

        iFeeDetailsView.hideLoading();

        iFeeDetailsView.pageUpdate(resultResponse);
    }

    @Override
    public void onFail(Throwable throwable) {
        iFeeDetailsView.hideLoading();
        iFeeDetailsView.onFail(throwable);
    }

    @Override
    public void onNetworkFailure() {
        iFeeDetailsView.hideLoading();
        iFeeDetailsView.onNetworkFailure();
    }
}
