package com.pappayaed.ui.studentfee;

/**
 * Created by yasar on 26/3/18.
 */

public interface IStudentFeePresenter {


    void getStudentProfile();

}
