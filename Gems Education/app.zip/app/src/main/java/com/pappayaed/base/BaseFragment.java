package com.pappayaed.base;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pappayaed.data.DataRepository;
import com.pappayaed.data.DataSource;
import com.pappayaed.data.helper.LogHelper;
import com.pappayaed.data.pref.Pref;
import com.pappayaed.data.pref.PreferencesHelper;
import com.pappayaed.data.remote.ApiService;
import com.pappayaed.data.remote.RemoteDataSourceHelper;
import com.pappayaed.data.retrofitclient.ApiEndPoint;
import com.pappayaed.data.retrofitclient.RetrofitClient;

/**
 * Created by yasar on 26/3/18.
 */

public class BaseFragment extends Fragment {

    private Pref pref;
    private RetrofitClient retrofitClient;
    private ApiService apiService;
    private RemoteDataSourceHelper remoteDataSource;
    public DataSource dataSource;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        LogHelper.loge("onAttach Fragment");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pref = PreferencesHelper.getPreferencesInstance(getContext());

        retrofitClient = RetrofitClient.getRetrofitClientInstance(ApiEndPoint.BASE_URL);

        apiService = retrofitClient.getRetrofit().create(ApiService.class);

        remoteDataSource = new RemoteDataSourceHelper(apiService);

        dataSource = new DataRepository(getContext(), remoteDataSource, pref);


        LogHelper.loge("onCreate Fragment");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogHelper.loge("onCreateView Fragment");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        LogHelper.loge("onViewCreated Fragment");
    }

    @Override
    public void onStart() {
        super.onStart();

        LogHelper.loge("onStart Fragment");
    }

    @Override
    public void onPause() {
        super.onPause();

        LogHelper.loge("onPause Fragment");
    }

    @Override
    public void onResume() {
        super.onResume();

        LogHelper.loge("onResume Fragment");
    }

    @Override
    public void onStop() {
        super.onStop();

        LogHelper.loge("onStop Fragment");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        LogHelper.loge("onDestroyView Fragment");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        LogHelper.loge("onDestroy Fragment");
    }

    @Override
    public void onDetach() {
        super.onDetach();

        LogHelper.loge("onDetach Fragment");
    }
}
