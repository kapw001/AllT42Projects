package com.pappayaed.ui.main;

import android.view.MenuItem;

/**
 * Created by yasar on 26/3/18.
 */

public interface IMainPresenter {

    void inflateBottomNavigationView();

    void bottomNavigationViewPosition(MenuItem item);


}
