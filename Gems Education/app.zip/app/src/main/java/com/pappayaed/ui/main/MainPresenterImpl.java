package com.pappayaed.ui.main;

import android.view.MenuItem;

import com.pappayaed.R;
import com.pappayaed.data.DataSource;

/**
 * Created by yasar on 26/3/18.
 */

public class MainPresenterImpl implements IMainPresenter {


    private IMainView iMainView;
    private DataSource dataSource;

    public MainPresenterImpl(IMainView iMainView, DataSource dataSource) {
        this.iMainView = iMainView;
        this.dataSource = dataSource;
    }

    @Override
    public void inflateBottomNavigationView() {


        String userType = dataSource.getUserType();

        if (userType != null && userType.equalsIgnoreCase("parent")) {

            iMainView.inflateBottomViewParent();

        }

    }

    @Override
    public void bottomNavigationViewPosition(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.circular:

                iMainView.moveToCircularFragment();

                break;

            case R.id.homework:

                iMainView.moveToStudentFeeFragment();

                break;

            case R.id.more:

                iMainView.moveToMoreFragment();

                break;

            default:
                iMainView.moveToCircularFragment();

                break;

        }

    }
}
