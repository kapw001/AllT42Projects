package com.pappayaed.ui.login;

/**
 * Created by yasar on 22/3/18.
 */

public interface ILoginPresenter {

    void validateCredentials(String email, String password);

    void getList();

}
