package com.pappayaed.ui.showfeedetails;


import com.pappayaed.base.BaseView;
import com.pappayaed.data.model.ResultResponse;

/**
 * Created by yasar on 27/3/18.
 */

public interface IFeeDetailsView extends BaseView {

    void pageUpdate(ResultResponse resultResponse);



}
