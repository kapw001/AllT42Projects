package com.pappayaed.ui.studentfee;

import com.pappayaed.ui.showprofile.StudentList;

import java.util.List;

/**
 * Created by yasar on 26/3/18.
 */

public class StudentFeePresenterImp implements IStudentFeePresenter, IStudentIntractor.OnFinishedListener {

    private IStudentFeeView iStudentFeeView;
    private IStudentIntractor iStudentIntractor;

    public StudentFeePresenterImp(IStudentFeeView iStudentFeeView, IStudentIntractor iStudentIntractor) {
        this.iStudentFeeView = iStudentFeeView;
        this.iStudentIntractor = iStudentIntractor;
    }

    @Override
    public void getStudentProfile() {

        iStudentIntractor.getStudentProfile(this);
    }

    @Override
    public void onSuccss(List<StudentList> studentLists) {

        if (studentLists.size() > 0) iStudentFeeView.setData(studentLists);
        else iStudentFeeView.emptyData();


    }

    @Override
    public void onFail(Throwable throwable) {

        iStudentFeeView.setError(throwable.getMessage());
    }

    @Override
    public void onNetworkFailure() {

        iStudentFeeView.setError("There is no internet avaiable");
    }
}
