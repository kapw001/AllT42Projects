package com.pappayaed.ui.splash;

/**
 * Created by yasar on 26/3/18.
 */

public interface ISplashView {


    void gotoMainActivity();

    void gotoLoginActivity();

}
