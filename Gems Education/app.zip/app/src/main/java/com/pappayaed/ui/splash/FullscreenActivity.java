package com.pappayaed.ui.splash;

import android.content.Intent;
import android.os.Bundle;

import com.pappayaed.ui.main.MainActivity;
import com.pappayaed.R;
import com.pappayaed.base.BaseActivity;
import com.pappayaed.ui.login.LoginActivity;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class FullscreenActivity extends BaseActivity implements ISplashView {


    private ISplashPresenter splashPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        splashPresenter = new SplashPresenterImpl(dataSource, this);

    }


    @Override
    protected void onResume() {
        super.onResume();

        splashPresenter.moveToNextActivity();
    }

    @Override
    protected void onPause() {
        super.onPause();
        splashPresenter.cancelHandler();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    @Override
    public void gotoMainActivity() {

        startActivity(new Intent(getApplicationContext(), MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));

    }

    @Override
    public void gotoLoginActivity() {

        startActivity(new Intent(getApplicationContext(), LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));

    }
}
