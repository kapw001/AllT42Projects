package com.pappayaed.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.pappayaed.data.DataRepository;
import com.pappayaed.data.DataSource;
import com.pappayaed.data.helper.LogHelper;
import com.pappayaed.data.pref.Pref;
import com.pappayaed.data.pref.PreferencesHelper;
import com.pappayaed.data.remote.ApiService;
import com.pappayaed.data.remote.RemoteDataSourceHelper;
import com.pappayaed.data.retrofitclient.ApiEndPoint;
import com.pappayaed.data.retrofitclient.RetrofitClient;

/**
 * Created by yasar on 26/3/18.
 */

public class BaseActivity extends AppCompatActivity {

    private Pref pref;
    private RetrofitClient retrofitClient;
    private ApiService apiService;
    private RemoteDataSourceHelper remoteDataSource;
    public DataSource dataSource;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pref = PreferencesHelper.getPreferencesInstance(getApplicationContext());

        retrofitClient = RetrofitClient.getRetrofitClientInstance(ApiEndPoint.BASE_URL);

        apiService = retrofitClient.getRetrofit().create(ApiService.class);

        remoteDataSource = new RemoteDataSourceHelper(apiService);

        dataSource = new DataRepository(getApplicationContext(), remoteDataSource, pref);

        LogHelper.loge("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();

        LogHelper.loge("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();

        LogHelper.loge("onResume");

    }

    @Override
    protected void onPause() {
        super.onPause();

        LogHelper.loge("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();

        LogHelper.loge("onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        LogHelper.loge("onDestory");
    }

    public void showSnackBar(View view, String msg) {

        Snackbar snackbar = Snackbar
                .make(view, msg, Snackbar.LENGTH_LONG);

        snackbar.show();
    }
}
