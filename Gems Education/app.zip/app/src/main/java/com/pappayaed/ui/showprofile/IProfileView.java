package com.pappayaed.ui.showprofile;

import java.util.List;

/**
 * Created by yasar on 26/3/18.
 */

public interface IProfileView {


    void displayProfile(String profileName, String userType, String profileImage);

    void gotoStudentProfileActivity();

    void setData(List<UserDetails> list);

    void setError(String msg);

    void setEmptyData();

}
