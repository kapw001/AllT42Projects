package com.pappayaed.ui.attendance;

/**
 * Created by yasar on 27/3/18.
 */

public interface IAttendancePresenter {


    void getAttendanceList(long student_ID, String start_date, String end_date);

}
